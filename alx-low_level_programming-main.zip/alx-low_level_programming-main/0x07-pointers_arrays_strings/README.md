Learning about pointers to pointers and arrays in C
 This contains exercises relating tp these
