Functions and Nested loops in C
