#include "main.h"

/**
  *mul - Function multiplies two numbers
  * @a: Function takes int a
  * @b: Function takes int b
  * Return: product of a and b
*/
int mul(int a, int b)
{
	int num = a * b;

	return (num);
}
