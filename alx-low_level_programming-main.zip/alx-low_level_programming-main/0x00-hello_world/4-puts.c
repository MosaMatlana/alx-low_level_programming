#include<stdio.h>

/**
 * main - program prints simple string to consol
 * Return: 0
 */
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
