Linked lists offer the advantage of insertion and deletion of elements in low runtime. This is because they generally store the values in random places in memory, unlike an array which groups the elements. 

This is an a practice on implemeting these in C.
