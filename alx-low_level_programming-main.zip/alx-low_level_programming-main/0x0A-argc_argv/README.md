Exploring argc and argv arguments to main func
