More singly linked lists
