#include "main.h"
/**
  * _abs-User Function
  * @n: num to be made absolute
  * Return: absolute n
 */
int _abs(int n)
{
	int num = (n < 0) ? -n : n;

	return (num);
}
