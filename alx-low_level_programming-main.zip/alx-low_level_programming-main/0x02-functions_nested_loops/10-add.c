#include "main.h"

/**
 * add - Function prototype
 * Description: Adds two intergers together
 * @x: The first number to add
 * @y: The second number to add
 * Return: The sum of x and y
 */

int add(int x, int y)
{
	return (x + y);
}
