Nested loops and functions
