Structures and typedef in C
