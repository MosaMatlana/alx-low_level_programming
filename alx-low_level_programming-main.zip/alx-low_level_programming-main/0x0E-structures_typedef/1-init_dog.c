#include "dog.h"
/**
  * int_dog - Finction intializes a struct dog
  * @d: Pointer to struct
  * @name: Pointer to dog name
  * @age: Dog age
  * @owner: Dog owner
  *
  * Return: Nothing
 */
void init_dog(struct dog *d, char *name, float age, char *owner)
{
	d = malloc(sizeof(struct dog));
	d->name;
	d->age;
	d->owner;
}
