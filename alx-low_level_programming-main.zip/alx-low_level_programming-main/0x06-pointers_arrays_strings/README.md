Learning more about pointers
