Data structures in C: Doubly Linked Lists
