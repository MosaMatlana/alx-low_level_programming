// This project is aimed at creating a replica of the built-in C function 'printf'

