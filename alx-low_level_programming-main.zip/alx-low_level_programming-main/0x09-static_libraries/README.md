Static libraries
