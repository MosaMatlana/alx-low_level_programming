Learning about pointers
