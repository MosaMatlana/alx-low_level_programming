#include "main.h"

/**
  * reset_to_98- Changes value to 98
  * @n: Input pointer
  * Return: void
  */

void reset_to_98(int *n)
{
	*n = 98;
}
