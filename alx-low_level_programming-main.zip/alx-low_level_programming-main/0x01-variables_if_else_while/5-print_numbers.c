#include<stdio.h>

/**
* main -Entry Point
* Return: 0
*/
int main(void)
{
	int al;

	for (al = 0; al < 10; al++)
		printf("%d", al);
	printf("\n");
	return (0);
}

