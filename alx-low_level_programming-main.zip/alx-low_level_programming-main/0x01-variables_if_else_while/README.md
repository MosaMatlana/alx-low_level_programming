Variables and loops in c
