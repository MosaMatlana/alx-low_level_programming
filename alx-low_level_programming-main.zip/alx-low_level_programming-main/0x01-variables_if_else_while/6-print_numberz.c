#include<stdio.h>

/**
* main -Entry Point
* Return: 0
*/
int main(void)
{
	int al;

	for (al = 48; al < 58; al++)
		putchar(al);
	putchar('\n');
	return (0);
}

