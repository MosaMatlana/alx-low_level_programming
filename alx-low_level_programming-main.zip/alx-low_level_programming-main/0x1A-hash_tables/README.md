The importance of data structures cannot be overstated.
### This is an introduction into to Hashmaps in C
### Task 0: Create an empty hashtable 
