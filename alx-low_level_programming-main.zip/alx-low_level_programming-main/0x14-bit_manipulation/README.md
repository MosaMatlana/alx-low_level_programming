Bit manipulation
