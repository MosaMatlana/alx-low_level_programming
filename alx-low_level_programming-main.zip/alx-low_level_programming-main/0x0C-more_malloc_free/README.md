Dynamic memory allocation using malloc and freeing using the - free - function
