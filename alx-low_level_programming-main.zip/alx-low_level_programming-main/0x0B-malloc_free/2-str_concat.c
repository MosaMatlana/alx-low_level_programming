#include "main.h"
#include <stdlib.h>


/**
  * str_concat  - Function concatinates one string to another
  * @s1: String 1
  * @s2: String 2
  *
  * Return: Pointer to array | NULL
*/

int _strlen(*string)
{
	int i = 0;

	for (; string[i] != '\0'; i++)
		i++;

	return (i);
}

/**
  * str_concat  - Function concatinates one string to another
  * @s1: String 1
  * @s2: String 2
  *
  * Return: Pointer to array | NULL
*/

/**
  * str_concat  - Function concatinates one string to another
  * @s1: String 1
  * @s2: String 2
  *
  * Return: Pointer to array | NULL
*/

