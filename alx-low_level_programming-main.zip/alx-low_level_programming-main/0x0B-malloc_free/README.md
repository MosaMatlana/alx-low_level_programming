Dynamic memory allocation using malloc
