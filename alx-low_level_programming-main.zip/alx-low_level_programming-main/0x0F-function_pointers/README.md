Pointing to functions - 
